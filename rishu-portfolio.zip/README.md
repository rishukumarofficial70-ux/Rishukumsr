# Rishu Kumar Portfolio

## Run locally
1. Extract `rishu-portfolio.zip`.
2. Open `index.html` in a browser.

The page uses Tailwind CSS and Google Fonts from CDNs, so an internet connection is needed for those resources to load.

## Publish with GitHub Pages
1. Upload `index.html` to the root of your GitHub repository.
2. Open repository **Settings → Pages**.
3. Under Build and deployment, choose **Deploy from a branch**.
4. Select your branch (usually `main`) and folder `/ (root)`, then save.

Note: The certificate section is clearly marked as a portfolio mock-up, not an independently verified official certificate. Replace its content with accurate details or an image of your original certificate if appropriate.
